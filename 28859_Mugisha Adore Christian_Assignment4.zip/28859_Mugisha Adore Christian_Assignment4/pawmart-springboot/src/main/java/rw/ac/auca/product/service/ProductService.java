package rw.ac.auca.product.service;

import rw.ac.auca.product.domain.Product;

import java.util.List;
import java.util.UUID;

/**
 * The Class ProductService.
 *
 * @version 1.0
 */
public interface ProductService {
    Product registerProduct(Product theProduct);
    Product updateProduct(Product theProduct);
    void deleteProduct(Product theProduct);
    Product findProductById(Product theProduct);
    List<Product> findAllProducts();

    // Business-logic action: reduce stock when a sale happens
    Product sellProduct(UUID productId, int quantity);
}
