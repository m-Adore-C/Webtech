package rw.ac.auca.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import rw.ac.auca.customer.domain.Customer;
import rw.ac.auca.customer.service.CustomerService;

import java.util.List;
import java.util.UUID;

/**
 * The Class CustomerController.
 *
 * @version 1.0
 */
@RestController
@RequestMapping("/customer")
public class CustomerController {

    @Autowired
    private CustomerService customerService;

    @GetMapping("/search-all")
    @ResponseStatus(HttpStatus.OK)
    public List<Customer> findAllRecords() {
        return customerService.findAllCustomers();
    }

    @GetMapping("/search-by-id/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Customer findRecordById(@PathVariable UUID id) {
        Customer theCustomer = new Customer();
        theCustomer.setId(id);
        return customerService.findCustomerById(theCustomer);
    }

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.OK)
    public Customer createCustomer(@RequestBody Customer theCustomer) {
        return customerService.registerCustomer(theCustomer);
    }

    @PostMapping("/update/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Customer updateCustomer(@PathVariable UUID id, @RequestBody Customer theCustomer) {
        theCustomer.setId(id);
        return customerService.updateCustomer(theCustomer);
    }

    @PostMapping("/delete/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteCustomer(@PathVariable UUID id) {
        Customer theCustomer = new Customer();
        theCustomer.setId(id);
        customerService.deleteCustomer(theCustomer);
    }
}
