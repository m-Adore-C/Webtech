package rw.ac.auca.product.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.auca.product.domain.Product;

import java.util.UUID;

/**
 * The Class ProductRepository.
 *
 * @version 1.0
 */
@Repository
public interface ProductRepository extends JpaRepository<Product, UUID> {
    boolean existsByCategoryId(UUID categoryId);
}
