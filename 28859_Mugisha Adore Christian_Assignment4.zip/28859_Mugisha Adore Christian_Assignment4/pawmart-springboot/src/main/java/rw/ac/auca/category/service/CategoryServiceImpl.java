package rw.ac.auca.category.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rw.ac.auca.category.domain.Category;
import rw.ac.auca.category.repository.CategoryRepository;
import rw.ac.auca.product.repository.ProductRepository;

import java.util.List;

/**
 * The Class CategoryServiceImpl.
 *
 * @version 1.0
 */
@Service
public class CategoryServiceImpl implements CategoryService {

    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private ProductRepository productRepository;

    @Override
    public Category registerCategory(Category theCategory) {
        // Business rule: category name is required
        if (theCategory.getCategoryName() == null || theCategory.getCategoryName().isBlank()) {
            throw new RuntimeException("Category name is required!");
        }
        // Business rule: category name must be unique
        if (categoryRepository.existsByCategoryNameIgnoreCase(theCategory.getCategoryName())) {
            throw new RuntimeException("A category named '" + theCategory.getCategoryName() + "' already exists!");
        }
        return categoryRepository.save(theCategory);
    }

    @Override
    public Category updateCategory(Category theCategory) {
        Category found = findCategoryById(theCategory);

        if (theCategory.getCategoryName() == null || theCategory.getCategoryName().isBlank()) {
            throw new RuntimeException("Category name is required!");
        }
        // Business rule: if renaming, the new name must not collide with a different category
        if (!found.getCategoryName().equalsIgnoreCase(theCategory.getCategoryName())
                && categoryRepository.existsByCategoryNameIgnoreCase(theCategory.getCategoryName())) {
            throw new RuntimeException("A category named '" + theCategory.getCategoryName() + "' already exists!");
        }

        found.setCategoryName(theCategory.getCategoryName());
        found.setDescription(theCategory.getDescription());
        return categoryRepository.save(found);
    }

    @Override
    public void deleteCategory(Category theCategory) {
        Category found = findCategoryById(theCategory);
        // Business rule: cannot delete a category that still has products assigned to it
        if (productRepository.existsByCategoryId(found.getId())) {
            throw new RuntimeException(
                    "Cannot delete category '" + found.getCategoryName() + "' because it still has products assigned to it!");
        }
        categoryRepository.delete(found);
    }

    @Override
    public Category findCategoryById(Category theCategory) {
        return categoryRepository.findById(theCategory.getId())
                .orElseThrow(() -> new RuntimeException("Category not found!"));
    }

    @Override
    public List<Category> findAllCategories() {
        return categoryRepository.findAll();
    }
}
