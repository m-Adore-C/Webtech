package rw.ac.auca.customer.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.auca.customer.domain.Customer;

import java.util.UUID;

/**
 * The Class CustomerRepository.
 *
 * @version 1.0
 */
@Repository
public interface CustomerRepository extends JpaRepository<Customer, UUID> {
    boolean existsByEmailIgnoreCase(String email);
}
