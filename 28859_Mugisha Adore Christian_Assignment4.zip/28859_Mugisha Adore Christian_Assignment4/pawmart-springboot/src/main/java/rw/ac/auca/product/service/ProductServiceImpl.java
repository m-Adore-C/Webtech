package rw.ac.auca.product.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rw.ac.auca.category.domain.Category;
import rw.ac.auca.category.repository.CategoryRepository;
import rw.ac.auca.product.domain.Product;
import rw.ac.auca.product.repository.ProductRepository;

import java.util.List;
import java.util.UUID;

/**
 * The Class ProductServiceImpl.
 *
 * @version 1.0
 */
@Service
public class ProductServiceImpl implements ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    @Override
    public Product registerProduct(Product theProduct) {
        validateProduct(theProduct);
        Category category = resolveCategory(theProduct);
        theProduct.setCategory(category);
        return productRepository.save(theProduct);
    }

    @Override
    public Product updateProduct(Product theProduct) {
        Product found = findProductById(theProduct);
        validateProduct(theProduct);
        Category category = resolveCategory(theProduct);

        found.setProductName(theProduct.getProductName());
        found.setPrice(theProduct.getPrice());
        found.setStock(theProduct.getStock());
        found.setCategory(category);
        return productRepository.save(found);
    }

    @Override
    public void deleteProduct(Product theProduct) {
        Product found = findProductById(theProduct);
        productRepository.delete(found);
    }

    @Override
    public Product findProductById(Product theProduct) {
        return productRepository.findById(theProduct.getId())
                .orElseThrow(() -> new RuntimeException("Product not found!"));
    }

    @Override
    public List<Product> findAllProducts() {
        return productRepository.findAll();
    }

    @Override
    public Product sellProduct(UUID productId, int quantity) {
        // Business rule: quantity sold must be positive
        if (quantity <= 0) {
            throw new RuntimeException("Quantity to sell must be greater than 0!");
        }
        Product found = productRepository.findById(productId)
                .orElseThrow(() -> new RuntimeException("Product not found!"));
        // Business rule: cannot sell more than what is in stock
        if (found.getStock() < quantity) {
            throw new RuntimeException(
                    "Insufficient stock for '" + found.getProductName() + "'. Available: " + found.getStock() + ", requested: " + quantity);
        }
        found.setStock(found.getStock() - quantity);
        return productRepository.save(found);
    }

    private void validateProduct(Product theProduct) {
        if (theProduct.getProductName() == null || theProduct.getProductName().isBlank()) {
            throw new RuntimeException("Product name is required!");
        }
        if (theProduct.getPrice() == null || theProduct.getPrice() <= 0) {
            throw new RuntimeException("Price must be greater than 0!");
        }
        if (theProduct.getStock() == null || theProduct.getStock() < 0) {
            throw new RuntimeException("Stock cannot be negative!");
        }
    }

    private Category resolveCategory(Product theProduct) {
        if (theProduct.getCategory() == null || theProduct.getCategory().getId() == null) {
            throw new RuntimeException("A valid category id is required for a product!");
        }
        return categoryRepository.findById(theProduct.getCategory().getId())
                .orElseThrow(() -> new RuntimeException("Category not found!"));
    }
}
