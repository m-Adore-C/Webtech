package rw.ac.auca.category.service;

import rw.ac.auca.category.domain.Category;

import java.util.List;

/**
 * The Class CategoryService.
 *
 * @version 1.0
 */
public interface CategoryService {
    Category registerCategory(Category theCategory);
    Category updateCategory(Category theCategory);
    void deleteCategory(Category theCategory);
    Category findCategoryById(Category theCategory);
    List<Category> findAllCategories();
}
