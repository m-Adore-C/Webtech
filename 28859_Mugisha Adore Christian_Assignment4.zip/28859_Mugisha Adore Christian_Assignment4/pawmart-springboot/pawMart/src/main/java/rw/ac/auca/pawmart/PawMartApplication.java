package rw.ac.auca.pawmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PawMartApplication {

    public static void main(String[] args) {
        SpringApplication.run(PawMartApplication.class, args);
    }

}
