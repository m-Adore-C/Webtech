package rw.ac.auca.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import rw.ac.auca.category.domain.Category;
import rw.ac.auca.category.service.CategoryService;

import java.util.List;
import java.util.UUID;

/**
 * The Class CategoryController.
 *
 * @version 1.0
 */
@RestController
@RequestMapping("/category")
public class CategoryController {

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/search-all")
    @ResponseStatus(HttpStatus.OK)
    public List<Category> findAllRecords() {
        return categoryService.findAllCategories();
    }

    @GetMapping("/search-by-id/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Category findRecordById(@PathVariable UUID id) {
        Category theCategory = new Category();
        theCategory.setId(id);
        return categoryService.findCategoryById(theCategory);
    }

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.OK)
    public Category createCategory(@RequestBody Category theCategory) {
        return categoryService.registerCategory(theCategory);
    }

    @PostMapping("/update/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Category updateCategory(@PathVariable UUID id, @RequestBody Category theCategory) {
        theCategory.setId(id);
        return categoryService.updateCategory(theCategory);
    }

    @PostMapping("/delete/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteCategory(@PathVariable UUID id) {
        Category theCategory = new Category();
        theCategory.setId(id);
        categoryService.deleteCategory(theCategory);
    }
}
