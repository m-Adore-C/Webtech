package rw.ac.auca.category.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import rw.ac.auca.category.domain.Category;

import java.util.UUID;

/**
 * The Class CategoryRepository.
 *
 * @version 1.0
 */
@Repository
public interface CategoryRepository extends JpaRepository<Category, UUID> {
    boolean existsByCategoryNameIgnoreCase(String categoryName);
}
