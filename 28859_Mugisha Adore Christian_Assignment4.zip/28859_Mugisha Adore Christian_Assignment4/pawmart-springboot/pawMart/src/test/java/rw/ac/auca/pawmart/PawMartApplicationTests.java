package rw.ac.auca.pawmart;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PawMartApplicationTests {

    @Test
    void contextLoads() {
    }

}
