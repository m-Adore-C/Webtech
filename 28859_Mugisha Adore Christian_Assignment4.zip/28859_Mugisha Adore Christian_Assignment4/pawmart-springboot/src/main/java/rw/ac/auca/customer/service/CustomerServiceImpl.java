package rw.ac.auca.customer.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import rw.ac.auca.customer.domain.Customer;
import rw.ac.auca.customer.repository.CustomerRepository;

import java.util.List;
import java.util.regex.Pattern;

/**
 * The Class CustomerServiceImpl.
 *
 * @version 1.0
 */
@Service
public class CustomerServiceImpl implements CustomerService {

    private static final Pattern EMAIL_PATTERN =
            Pattern.compile("^[\\w.+-]+@[\\w-]+\\.[a-zA-Z]{2,}$");
    private static final Pattern PHONE_PATTERN =
            Pattern.compile("^\\+?[0-9]{7,15}$");

    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public Customer registerCustomer(Customer theCustomer) {
        validateCustomer(theCustomer);
        // Business rule: email must be unique across customers
        if (customerRepository.existsByEmailIgnoreCase(theCustomer.getEmail())) {
            throw new RuntimeException("A customer with email '" + theCustomer.getEmail() + "' already exists!");
        }
        return customerRepository.save(theCustomer);
    }

    @Override
    public Customer updateCustomer(Customer theCustomer) {
        Customer found = findCustomerById(theCustomer);
        validateCustomer(theCustomer);

        // Business rule: if changing email, the new one must not belong to someone else
        if (!found.getEmail().equalsIgnoreCase(theCustomer.getEmail())
                && customerRepository.existsByEmailIgnoreCase(theCustomer.getEmail())) {
            throw new RuntimeException("A customer with email '" + theCustomer.getEmail() + "' already exists!");
        }

        found.setFullName(theCustomer.getFullName());
        found.setEmail(theCustomer.getEmail());
        found.setPhone(theCustomer.getPhone());
        found.setAddress(theCustomer.getAddress());
        return customerRepository.save(found);
    }

    @Override
    public void deleteCustomer(Customer theCustomer) {
        Customer found = findCustomerById(theCustomer);
        customerRepository.delete(found);
    }

    @Override
    public Customer findCustomerById(Customer theCustomer) {
        return customerRepository.findById(theCustomer.getId())
                .orElseThrow(() -> new RuntimeException("Customer not found!"));
    }

    @Override
    public List<Customer> findAllCustomers() {
        return customerRepository.findAll();
    }

    private void validateCustomer(Customer theCustomer) {
        if (theCustomer.getFullName() == null || theCustomer.getFullName().isBlank()) {
            throw new RuntimeException("Full name is required!");
        }
        if (theCustomer.getEmail() == null || !EMAIL_PATTERN.matcher(theCustomer.getEmail()).matches()) {
            throw new RuntimeException("A valid email address is required!");
        }
        if (theCustomer.getPhone() == null || !PHONE_PATTERN.matcher(theCustomer.getPhone()).matches()) {
            throw new RuntimeException("Phone number must be 7-15 digits, optionally starting with +!");
        }
    }
}
