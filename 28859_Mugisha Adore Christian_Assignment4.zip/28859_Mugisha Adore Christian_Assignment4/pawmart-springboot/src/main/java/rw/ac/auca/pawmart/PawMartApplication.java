package rw.ac.auca.pawmart;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.persistence.autoconfigure.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

/**
 * Domain features (category, product, customer) live as sibling packages
 * under rw.ac.auca, not nested inside rw.ac.auca.pawmart, so they must be
 * scanned explicitly - same pattern as the StockManagementSystem example.
 */
@SpringBootApplication
@ComponentScan(basePackages = "rw.ac.auca.*")
@EnableJpaRepositories(basePackages = "rw.ac.auca.*")
@EntityScan(basePackages = "rw.ac.auca.*")
public class PawMartApplication {

    public static void main(String[] args) {
        SpringApplication.run(PawMartApplication.class, args);
    }

}
