# PawMart – Pet Store Management System

Built to follow the exact structure and conventions from the trainer's
`StockManagementSystem` example. This file also documents those rules so you
can reuse the same pattern to build any of your other project ideas.

## Entities used (3 required by the assignment)
- **Category** ↔ **Product**: real one-to-many relationship
- **Customer**: independent entity, different validation needs (unique email, phone format)

## The Template Rules (extracted from the trainer's example)

### 1. Package layout is feature-based, not layer-based
Each domain/feature gets its **own top-level package** directly under the
root package (`rw.ac.auca`), each containing its own `domain`, `repository`,
and `service` sub-packages:
```
rw.ac.auca
├── base/                     BaseEntity (shared by all entities)
├── pawmart/                  Main @SpringBootApplication class
├── controller/                All REST controllers live together here
├── category/
│   ├── domain/Category.java
│   ├── repository/CategoryRepository.java
│   └── service/CategoryService.java + CategoryServiceImpl.java
├── product/
│   ├── domain/Product.java
│   ├── repository/ProductRepository.java
│   └── service/ProductService.java + ProductServiceImpl.java
└── customer/
    ├── domain/Customer.java
    ├── repository/CustomerRepository.java
    └── service/CustomerService.java + CustomerServiceImpl.java
```
This differs from the more common `model/`, `repository/`, `service/`,
`controller/` top-level split — here it's grouped **by feature first**,
layer second (except controllers, which the trainer's example keeps together
in one shared package).

### 2. BaseEntity is mandatory
Every entity extends `BaseEntity`, which supplies:
- `UUID id` (auto-generated, not `Long`)
- `createdAt` / `updatedAt` (auto-managed by Hibernate via `@CreationTimestamp` / `@UpdateTimestamp`)

Never redeclare `id` in a domain entity.

### 3. Because domain packages are siblings, not children, of the app package
The `@SpringBootApplication` class sits in `rw.ac.auca.pawmart`, but
`category`, `product`, `customer`, `base`, and `controller` are **siblings**
of `pawmart`, not nested inside it. Spring's default component scan only
looks at the application class's own package and subpackages, so it would
miss all of them. That's why the main class explicitly declares:
```java
@ComponentScan(basePackages = "rw.ac.auca.*")
@EnableJpaRepositories(basePackages = "rw.ac.auca.*")
@EntityScan(basePackages = "rw.ac.auca.*")
```
If you add a new feature package, it's automatically picked up — no changes
needed here, as long as it also sits under `rw.ac.auca`.

### 4. Entities use Lombok, not manual getters/setters
`@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Entity` on every
domain class. Requires the Lombok IDE plugin + annotation processing enabled.

### 5. Service = interface + Impl, always
Every feature has a `XService` interface and a `XServiceImpl` class. Method
names describe intent, not generic CRUD verbs: `registerX`, `updateX`,
`deleteX`, `findXById`, `findAllXs`. `findXById` / `deleteX` take the entity
itself (with only `id` populated) rather than a raw `UUID`, matching the
trainer's `findProductById(Product theProduct)` signature.

### 6. Business logic validation lives in the ServiceImpl, as plain checks
No Bean Validation annotations (`@NotBlank`, `@Email`, etc.) and no global
exception handler — the trainer's example keeps it simple: manual `if`
checks in the service method, throwing `RuntimeException("message")`.
This project follows that exact style. Rules implemented here:

| Entity | Rule | Where |
|---|---|---|
| Category | Name required, must be unique | `CategoryServiceImpl.registerCategory/updateCategory` |
| Category | Can't delete if products still reference it | `CategoryServiceImpl.deleteCategory` |
| Product | Name required, price > 0, stock >= 0 | `ProductServiceImpl.validateProduct` |
| Product | Category referenced must exist | `ProductServiceImpl.resolveCategory` |
| Product | Can't sell more than available stock | `ProductServiceImpl.sellProduct` |
| Customer | Full name required | `CustomerServiceImpl.validateCustomer` |
| Customer | Email must be valid format and unique | `CustomerServiceImpl.validateCustomer` / `registerCustomer` |
| Customer | Phone must match digit pattern | `CustomerServiceImpl.validateCustomer` |

### 7. Controllers use custom action-style paths, and only GET/POST
Instead of `GET /api/products/{id}`, the trainer's style is:
```
GET  /product/search-all
GET  /product/search-by-id/{id}
POST /product/create
POST /product/update/{id}
POST /product/delete/{id}
```
`@RestController`, base path is the lowercase entity name (no `/api` prefix),
`@ResponseStatus(HttpStatus.OK)` is set explicitly on every method. This
project's assignment brief restricts requests to **GET and POST only**, so
update/delete/sell all use `@PostMapping` with an action word in the path
(`/update/{id}`, `/delete/{id}`, `/sell/{id}`) instead of `PUT`/`DELETE`/`PATCH`.

## Tech Stack
- Java 25
- Spring Boot 4.1.1 (`spring-boot-starter-webmvc`, `spring-boot-starter-data-jpa`, `spring-boot-starter-thymeleaf`)
- Lombok
- Spring Boot DevTools
- PostgreSQL

## Prerequisites
- Java 25+, Maven
- PostgreSQL running locally
- Lombok IDE plugin + annotation processing enabled

## Database Setup
```sql
CREATE DATABASE pawmart_db;
```
Connection details are in `src/main/resources/application.properties`
(defaults: `postgres` / `postgres` on `localhost:5432`).
`spring.jpa.hibernate.ddl-auto=create-drop` means tables are recreated fresh
every time you restart the app (matches the trainer's example) — switch to
`update` once you want data to persist across restarts.

## How to Run
```
mvn spring-boot:run
```
API available at `http://localhost:8080`.

## Testing with Postman
Import `PawMart.postman_collection.json`. Suggested order:
1. Create a Category → copy its `id` from the response
2. Create a Product using that category's `id`
3. Try deleting the Category → should fail (products still reference it)
4. Delete the Product, then the Category → should succeed
5. Create a Customer, then try creating another with the same email → should fail

## Using this as a template for your other projects
To start a new project (e.g. the Garage Management System, Library
Management System, etc.) from this same foundation:
1. Copy this folder, rename `artifactId`/`name` in `pom.xml`.
2. Rename the `pawmart` package to your new app name; keep `base` and `controller` as-is.
3. Replace `category`/`product`/`customer` packages with your chosen 3 entities,
   each with its own `domain` / `repository` / `service` sub-packages.
4. Keep `BaseEntity`, the `@ComponentScan`/`@EntityScan`/`@EnableJpaRepositories`
   pattern in the main class, the service interface+Impl split, and the manual
   `RuntimeException`-based validation style — that's what makes it consistent
   with the trainer's example.
