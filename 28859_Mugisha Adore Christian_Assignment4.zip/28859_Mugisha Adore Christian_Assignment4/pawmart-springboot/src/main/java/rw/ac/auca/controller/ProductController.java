package rw.ac.auca.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import rw.ac.auca.product.domain.Product;
import rw.ac.auca.product.service.ProductService;

import java.util.List;
import java.util.UUID;

/**
 * The Class ProductController.
 *
 * @version 1.0
 */
@RestController
@RequestMapping("/product")
public class ProductController {

    @Autowired
    private ProductService productService;

    @GetMapping("/search-all")
    @ResponseStatus(HttpStatus.OK)
    public List<Product> findAllRecords() {
        return productService.findAllProducts();
    }

    @GetMapping("/search-by-id/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Product findRecordById(@PathVariable UUID id) {
        Product theProduct = new Product();
        theProduct.setId(id);
        return productService.findProductById(theProduct);
    }

    @PostMapping("/create")
    @ResponseStatus(HttpStatus.OK)
    public Product createProduct(@RequestBody Product theProduct) {
        return productService.registerProduct(theProduct);
    }

    @PostMapping("/update/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Product updateProduct(@PathVariable UUID id, @RequestBody Product theProduct) {
        theProduct.setId(id);
        return productService.updateProduct(theProduct);
    }

    @PostMapping("/delete/{id}")
    @ResponseStatus(HttpStatus.OK)
    public void deleteProduct(@PathVariable UUID id) {
        Product theProduct = new Product();
        theProduct.setId(id);
        productService.deleteProduct(theProduct);
    }

    // Business-logic action: sell N units, enforcing stock >= 0
    @PostMapping("/sell/{id}")
    @ResponseStatus(HttpStatus.OK)
    public Product sellProduct(@PathVariable UUID id, @RequestParam int quantity) {
        return productService.sellProduct(id, quantity);
    }
}
